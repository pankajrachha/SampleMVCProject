package com.web.configuration.utility;

public class debug {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String [] sa = {"san","kalp"};
		
		for (String n :sa)
		{
			switch(n)
			{
			case "san":
				System.out.println("First half");
				break;
			case "kalp":
				System.out.println("Second half");
			}
		}

	}

}
